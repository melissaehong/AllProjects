from django.shortcuts import render, redirect
from django.urls import reverse

from django.db.models import Count
from ..courses_app.models import Course
from ..login_reg_app.models import User

# Create your views here.
def index(request):
    context = {
        'users': User.objects.all(),
        'courses' : Course.objects.annotate(students=Count('users'))
    }
    return render(request, 'courses_and_users_app/index.html', context)

def create(request):
    Course.objects.add_user_to_course(request.POST)
    return redirect(reverse('courses_users_index'))
