from __future__ import unicode_literals

from django.apps import AppConfig


class CoursingConfig(AppConfig):
    name = 'coursing'
