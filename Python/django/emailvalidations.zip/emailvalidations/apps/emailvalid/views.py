from django.shortcuts import render
from .models import Email
import re

# Create your views here.
def index(request):
    email = Email.objects.login('melissahong1@gmail.com')
    return render('testappy/index.html')

def process(request):
    errors = []
    if request.method == 'POST':
        emailregex = re.compile(r'^[a-zA-Z0-9\.\+_-]+@[a-zA-Z0-9\._-]+\.[a-zA-Z]*$')
        if not emailregex.match(request.POST['email']):
            return redirect('/')

        if emailregex is true:

            return render('testappy/success.html')
