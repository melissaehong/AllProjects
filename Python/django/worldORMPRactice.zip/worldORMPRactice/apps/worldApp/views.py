from django.shortcuts import render
from . import models
# Create your views here.
def index(req):
    slovene = models.Countries.objects.filter(languagetocountry__language='slovene')
    cities = models.Cities.objects.all(citytocountry__country)
    languages = models.Languages.objects.filter(language='slovene')
    # prints the queries
    print (50*"*")
    print cities.query
    print (50*"*")
    print languages.query
    print (50*"*")
    return render(req, 'worldApp/index.html', context={'cities':cities})
