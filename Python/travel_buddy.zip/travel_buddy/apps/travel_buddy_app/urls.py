from django.conf.urls import url
from . import views
from views import index, login, register, travels, logout, show, join

urlpatterns = [
    url(r'^main$', views.index, name='index'),
    url(r'^register$', views.register, name='login'),
    url(r'^login$', views.login, name='register'),
    url(r'^travels$', views.travels, name='travels'),
    url(r'^logout$', views.logout, name='logout'),
    url(r'^add/$', views.add, name='add'),
    url(r'^create$', views.create, name='create'),
    url(r'^(?P<id>\d+)/$', show, name='show'),
    url(r'^(?P<id>\d+)/join/$', join, name='join')
]
