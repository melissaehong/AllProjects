from django.shortcuts import render, redirect
from django.contrib import messages
from models import User, Trip, Join
from django.urls import reverse

# Create your views here.
def index(request):
    return render(request, 'travel_buddy_app/index.html')


def login(request):
    result = User.objects.validateLogin(request)

    if result[0] == False:
        print_messages(request, result[1])
        return redirect(reverse('index'))

    return log_user_in(request, result[1])

def register(request):
    if request.method == 'POST':
        result = User.objects.validateRegister(request)

        if result[0] == False:
            print_messages(request, result[1])
            return redirect(reverse('index'))

        return log_user_in(request, result[1])

def travels(request):
    context = {
        'trips': Trip.objects.all()
    }

    if not 'user' in request.session:
        return redirect('/')
    return render(request, 'travel_buddy_app/travels.html', context)

def print_messages(request, message_list):
    for message in message_list:
        messages.add_message(request, messages.INFO, message)

def log_user_in(request, user):
    request.session['user'] = {
    'id' : user.id,
    'first_name' : user.first_name,
    'last_name' : user.last_name,
    'email' : user.email
    }
    return redirect(reverse('travels'))

def logout(request):
    request.session.pop('user')
    return redirect(reverse('index'))

def add(request):
    return render(request, 'travel_buddy_app/add.html')

def create(request):
    trip = Trip.objects.create(destination=request.POST['destination'], description=request.POST['description'], datefrom=request.POST['datefrom'], dateend=request.POST['dateend'], user_id=request.session['user']['id'])

    return redirect(reverse('travels'))

def show(request, id):
    if not 'user' in request.session:
        return redirect('/')
    trip = Trip.objects.get(id=id)
    return render(request, 'travel_buddy_app/show.html', {'trip': trip})

def join(request, id):
    if not 'user' in request.session:
        return redirect('/')
    trip = Trip.objects.update(id=id)
    return render(request, 'travel_buddy_app/show.html', {'trip': trip})
